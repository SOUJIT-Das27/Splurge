import FooterCSS from "./Footer.module.css";
import {assets} from "../../assets/assets.js";

export const Footer = () => {
  return (
    <div className={FooterCSS.footer} id={FooterCSS.footer}>
        <div className={FooterCSS.footerContent}>
            <div className={FooterCSS.footerContentLeft}>
                <img src={assets.logo} className={FooterCSS.logo} alt=""/>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam pariatur eaque, ad</p>
                <div className={FooterCSS.footerSocialIcon}>
                    <img src={assets.facebook_icon} alt=""/>
                    <img src={assets.twitter_icon} alt=""/>
                    <img src={assets.linkedin_icon} alt=""/>
                </div>
            </div>
            <div className={FooterCSS.footerContentCenter}>
                <h2>COMPANY</h2>
                <ul>
                    <li>Home</li>
                    <li>About us</li>
                    <li>Delivery</li>
                    <li>Privacy Policy</li>
                </ul>
            </div>
            <div className={FooterCSS.footerContentRight}>
                <h2>GET IN TOUCH</h2>
                <ul>
                    <li>+1-555-345-234</li>
                    <li>contact@splurge.com</li>
                </ul>
            </div>
        </div>
        <hr/>
        <p className={FooterCSS.footerCopyright}>
            copyright 2024 &#169; Splurge.com - All Rights Reserved
        </p>
    </div>
  )
}
