import {useState,useContext} from "react";
import Nav from "./Navbar.module.css";
import search from "../../assets/icons/search_24dp_5F6368_FILL0_wght400_GRAD0_opsz24.svg";
import bag from "../../assets/icons/dish-removebg-preview.png";
import {Link, useNavigate} from "react-router-dom";
import {assets} from "../../assets/assets.js";
import { StoreContext } from "../../context/StoreContext.jsx";

function Navbar({setShowLogin}) {

    const {getTotalCartAmount,token,setToken} = useContext(StoreContext);
    const [menu,setMenu] = useState("home");

    const navigate = useNavigate();

    const logout = ()=>{
      localStorage.removeItem("token");
      setToken("");
      navigate("/");
    }
  return (
    
    <div className={Nav.navbar}>
      <Link to="/"><img id={Nav.logo} src={assets.logo} alt="splurge-logo"/></Link>
      <ul className={Nav.navbarMenu}>
        <Link to="/" onClick={()=>{setMenu("home")}}className={menu === "home"?Nav.active:""}>home</Link>
        <a href="#Brands_topBrand__cYCq6" onClick={()=>{setMenu("menu")}}className={menu === "menu"?Nav.active:""}>menu</a>
        <a href="#AppDownload_AppDownLoad__CFKRU" onClick={()=>{setMenu("mobile-app")}}className={menu === "mobile-app"?Nav.active:""}>mobile-app</a>
        <a href="#Footer_footer__xWYBf" onClick={()=>{setMenu("contact-us")}}className={menu === "contact-us"?Nav.active:""}>contact-us</a>
      </ul>

      <div className={Nav.navbarRight}>
        <img src={search} alt="search button"/>
        <div className={Nav.shoppingItem}>
            <Link to="/cart"><img src={bag} alt="bag-image"/></Link>
            <div className={getTotalCartAmount()?Nav.itemBuy:""}></div>
        </div>
        {
          !token?<button onClick={()=>{setShowLogin(true);}}>sign in</button>:
          <div className={Nav.navbar_profile}>
            <img src={assets.profile_icon} alt="" />
            <ul className={Nav.nav_profile_dropdown}>
              <li onClick={()=>{navigate("/myorders")}}>
                <img src={assets.bag_icon} alt="" />
                <p>Orders</p>
              </li>
              <hr/>
              <li onClick={logout}>
                <img src={assets.logout_icon} alt="" />
                <p>Logout</p>
              </li>
            </ul>
          </div>
        }
        
        
      </div>
    </div>
  );
}

export default Navbar;