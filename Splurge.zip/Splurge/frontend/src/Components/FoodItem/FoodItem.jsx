import buy from "./FoodItem.module.css";
import { assets } from "../../assets/assets.js";
import { useContext } from "react";
import { StoreContext } from "../../context/StoreContext.jsx";

export const FoodItem = ({id,name,image,price,description}) => {
    const {url,cartItems,addToCart,removeFromCart} = useContext(StoreContext);
  return (
    <div className={buy.foodItem}>
        <div className = {buy.imageContainer}>
            <img src={`${url}/images/${image}`} className={buy.foodItemImage} alt={buy.name}/>
            {
                !cartItems[id] ? <img className={buy.add} onClick={()=>{addToCart(id)}} src={assets.plus_white} alt=""/> 
                 :
                    <div className={buy.foodItemCounter}>
                        <img src={assets.plus_red} alt="" onClick={()=>{removeFromCart(id)}}/>
                        <p>{cartItems[id]}</p>
                        <img src={assets.plus_green} alt="" onClick={()=>{addToCart(id)}}/>
                    </div>
            }
        </div>

        <div className={buy.footDetails}>
            <div className={buy.foodNameRating}>
                <p>{name}</p>
                <img src={assets.rating_star} alt=""/>
            </div>
            <p className={buy.foodItemDesc}>{description}</p>
            <p className={buy.foodItemPrice}>${price}</p>
        </div>
    </div>
  )
}
