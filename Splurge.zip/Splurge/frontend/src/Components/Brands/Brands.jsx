import { brands } from "../../assets/assets.js";
import Brand from "./Brands.module.css";

export const Brands = ({category,setCategory}) => {
  return (
    <div className={Brand.topBrand} id={Brand.topBrand}>
    <h1>Top Brands</h1>
    <br/>
      <div className={Brand.brandLogo}>
            {
                brands.map((brand)=>{
                    return <div className={Brand.brandList} onClick={()=>{setCategory(prev=>prev===brand.brand_name?"All":brand.brand_name)}}>
                              <img className={(category===brand.brand_name)?Brand.active:Brand.none} src={brand.brand_image} alt={brand.brand_name}/>
                              <p>{brand.brand_name}</p>
                            </div>
                })
            }
      </div>
      <hr/>
    </div>
  )
}
