import Head from "./Header.module.css";
export const Header = () => {
  return (
    <div className={Head.header}>
        <div className={Head.headerContent}>
            <h1>Order your favourite meal</h1>
            <p>Discover mouth-watering dishes from top restaurants near you, delivered straight to your door. Satisfy your cravings with just a snap!</p>
            <button>View Menu</button>
        </div>
    </div>
  )
}
