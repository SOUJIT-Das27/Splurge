import React from 'react'
import {assets} from "../../assets/assets.js";
import appdwnld from "./AppDownload.module.css";

const AppDownload = () => {
  return (
    <div className={appdwnld.AppDownLoad} id={appdwnld.AppDownLoad}>
        <p>For better experience download our <br/>
        Splurge App</p>
        <div className={appdwnld.AppDownLoadPlatform}>
            <img src={assets.google_play}/>
            <img src={assets.app_store}/>
        </div>
    </div>
  )
}

export default AppDownload