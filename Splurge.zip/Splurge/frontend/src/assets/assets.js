import rating_star from "./icons/rating_starts.png";
import plus_white from "./icons/add_icon_white.png";
import plus_green from "./icons/add_icon_green.png";
import plus_red from "./icons/remove_icon_red.png";
import logo from "./logo_food.png";
import facebook_icon from "./icons/facebook_icon.png";
import twitter_icon from "./icons/twitter_icon.png";
import linkedin_icon from "./icons/linkedin_icon.png";
import google_play from "./icons/play_store.png";
import app_store from "./icons/app_store.png";
import cross_icon from "./icons/cross_icon.png"
import profile_icon from "./icons/profile_icon.png"
import bag_icon from "./icons/bag_icon.png"
import logout_icon from "./icons/logout_icon.png"
import parcel_icon from "./icons/parcel_icon.png"

//Brands
import kfc from "./Brands/KFC-Logo.wine (1).png";
import subway from "./Brands/OS_DE19085M_1.png";
import mcdonalds from "./Brands/Mcdonalds-logo-on-transparent-background-PNG.png";
import wowMomo from "./Brands/315963204_6020584974618930_4896024432537435838_n.png";
import wowChina from "./Brands/WOW_China-1.png";
import wowChicken from "./Brands/366630319_281916277787261_839006535175630464_n.png";
import baskinRobbins from "./Brands/baskin.png";
import dominos from "./Brands/dominosss (1).png";
import bking from "./Brands/burger_king.png";

//Menu
import menu_1 from './menu/menu_1.png'
import menu_2 from './menu/menu_2.png'
import menu_3 from './menu/menu_3.png'
import menu_4 from './menu/menu_4.png'
import menu_5 from './menu/menu_5.png'
import menu_6 from './menu/menu_6.png'
import menu_7 from './menu/menu_7.png'
import menu_8 from './menu/menu_8.png'


//food items
import food_1 from "./food_items/food_1.png";
import food_2 from "./food_items/food_2.png";
import food_3 from "./food_items/food_3.png";
import food_4 from "./food_items/food_4.png";
import food_5 from "./food_items/food_5.png";
import food_6 from "./food_items/food_6.png";
import food_7 from "./food_items/food_7.png";
import food_8 from "./food_items/food_8.png";
import food_9 from "./food_items/food_9.png";
import food_10 from "./food_items/food_10.png";
import food_11 from "./food_items/food_11.png";
import food_12 from "./food_items/food_12.png";
import food_13 from "./food_items/food_13.png";
import food_14 from "./food_items/food_14.png";
import food_15 from "./food_items/food_15.png";
import food_16 from "./food_items/food_16.png";
import food_17 from "./food_items/food_17.png";
import food_18 from "./food_items/food_18.png";
import food_19 from "./food_items/food_19.png";
import food_20 from "./food_items/food_20.png";
import food_21 from "./food_items/food_21.png";
import food_22 from "./food_items/food_22.png";
import food_23 from "./food_items/food_23.png";
import food_24 from "./food_items/food_24.png";
import food_25 from "./food_items/food_25.png";
import food_26 from "./food_items/food_26.png";
import food_27 from "./food_items/food_27.png";
import food_28 from "./food_items/food_28.png";
import food_29 from "./food_items/food_29.png";
import food_30 from "./food_items/food_30.png";
import food_31 from "./food_items/food_32.png";
import food_32 from "./food_items/food_32.png";


export const assets = {
    rating_star,
    plus_white,
    plus_green,
    plus_red,
    logo,
    facebook_icon,
    twitter_icon,
    linkedin_icon,
    google_play,
    app_store,
    cross_icon,
    profile_icon,
    bag_icon,
    logout_icon,
    parcel_icon
}

export const menu_list = [
    {
        menu_name: "Salad",
        menu_image: menu_1
    },
    {
        menu_name: "Rolls",
        menu_image: menu_2
    },
    {
        menu_name: "Deserts",
        menu_image: menu_3
    },
    {
        menu_name: "Sandwich",
        menu_image: menu_4
    },
    {
        menu_name: "Cake",
        menu_image: menu_5
    },
    {
        menu_name: "Pure Veg",
        menu_image: menu_6
    },
    {
        menu_name: "Pasta",
        menu_image: menu_7
    },
    {
        menu_name: "Noodles",
        menu_image: menu_8
    }]


export const brands = [
    {
        brand_name:"Noodles",
        brand_image:kfc
    },
    {
        brand_name:"Sandwich",
        brand_image:subway
    },
    {
        brand_name:"McDonalds",
        brand_image:mcdonalds
    },
    {
        brand_name:"Momo",
        brand_image:wowMomo
    },
    {
        brand_name:"China",
        brand_image:wowChina
    },
    {
        brand_name:"Chicken",
        brand_image:wowChicken
    },
    {
        brand_name:"Baskin",
        brand_image:baskinRobbins
    },
    {
        brand_name:"Domino's",
        brand_image:dominos
    },
    {
        brand_name:"Burger",
        brand_image:bking
    }
]


export const food_list = [
    {
        _id: "1",
        name: "Greek salad",
        image: food_1,
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Salad"
    },
    {
        _id: "2",
        name: "Veg salad",
        image: food_2,
        price: 18,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Salad"
    }, {
        _id: "3",
        name: "Clover Salad",
        image: food_3,
        price: 16,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Salad"
    }, {
        _id: "4",
        name: "Chicken Salad",
        image: food_4,
        price: 24,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Salad"
    }, {
        _id: "5",
        name: "Lasagna Rolls",
        image: food_5,
        price: 14,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Rolls"
    }, {
        _id: "6",
        name: "Peri Peri Rolls",
        image: food_6,
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Rolls"
    }, {
        _id: "7",
        name: "Chicken Rolls",
        image: food_7,
        price: 20,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Rolls"
    }, {
        _id: "8",
        name: "Veg Rolls",
        image: food_8,
        price: 15,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Rolls"
    }, {
        _id: "9",
        name: "Ripple Ice Cream",
        image: food_9,
        price: 14,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Deserts"
    }, {
        _id: "10",
        name: "Fruit Ice Cream",
        image: food_10,
        price: 22,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Deserts"
    }, {
        _id: "11",
        name: "Jar Ice Cream",
        image: food_11,
        price: 10,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Deserts"
    }, {
        _id: "12",
        name: "Vanilla Ice Cream",
        image: food_12,
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Deserts"
    },
    {
        _id: "13",
        name: "Chicken Sandwich",
        image: food_13,
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Sandwich"
    },
    {
        _id: "14",
        name: "Vegan Sandwich",
        image: food_14,
        price: 18,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Sandwich"
    }, {
        _id: "15",
        name: "Grilled Sandwich",
        image: food_15,
        price: 16,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Sandwich"
    }, {
        _id: "16",
        name: "Bread Sandwich",
        image: food_16,
        price: 24,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Sandwich"
    }, {
        _id: "17",
        name: "Cup Cake",
        image: food_17,
        price: 14,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Cake"
    }, {
        _id: "18",
        name: "Vegan Cake",
        image: food_18,
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Cake"
    }, {
        _id: "19",
        name: "Butterscotch Cake",
        image: food_19,
        price: 20,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Cake"
    }, {
        _id: "20",
        name: "Sliced Cake",
        image: food_20,
        price: 15,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Cake"
    }, {
        _id: "21",
        name: "Garlic Mushroom ",
        image: food_21,
        price: 14,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Pure Veg"
    }, {
        _id: "22",
        name: "Fried Cauliflower",
        image: food_22,
        price: 22,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Pure Veg"
    }, {
        _id: "23",
        name: "Mix Veg Pulao",
        image: food_23,
        price: 10,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Pure Veg"
    }, {
        _id: "24",
        name: "Rice Zucchini",
        image: food_24,
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Pure Veg"
    },
    {
        _id: "25",
        name: "Cheese Pasta",
        image: food_25,
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Pasta"
    },
    {
        _id: "26",
        name: "Tomato Pasta",
        image: food_26,
        price: 18,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Pasta"
    }, {
        _id: "27",
        name: "Creamy Pasta",
        image: food_27,
        price: 16,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Pasta"
    }, {
        _id: "28",
        name: "Chicken Pasta",
        image: food_28,
        price: 24,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Pasta"
    }, {
        _id: "29",
        name: "Buttter Noodles",
        image: food_29,
        price: 14,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Noodles"
    }, {
        _id: "30",
        name: "Veg Noodles",
        image: food_30,
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Noodles"
    }, {
        _id: "31",
        name: "Somen Noodles",
        image: food_31,
        price: 20,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Noodles"
    }, {
        _id: "32",
        name: "Cooked Noodles",
        image: food_32,
        price: 15,
        description: "Food provides essential nutrients for overall health and well-being",
        category: "Noodles"
    }
]