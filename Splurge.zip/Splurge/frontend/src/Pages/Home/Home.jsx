import {useState} from 'react';
import {Header} from "../../Components/Header/Header";
import {Brands} from "../../Components/Brands/Brands";
import { FoodDisplay } from '../../Components/FoodDisplay/FoodDisplay';
import AppDownload from '../../Components/AppDownload/AppDownload';
import { ExploreMenu } from '../../Components/ExploreMenu/ExploreMenu';

export const Home = () => {
  const [category,setCategory] = useState("All");
  return (
    <div className="home">
        <Header/>
        <Brands category={category} setCategory={setCategory}/>
        <ExploreMenu category={category} setCategory={setCategory}/>
        <FoodDisplay category={category}/>
        <AppDownload/>
    </div>
  )
}
