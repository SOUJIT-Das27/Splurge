import React from 'react'
import Nav from "./Navbar.module.css";
import {assets} from "../../assets/assets";

const Navbar = () => {
  return (
    <div className={Nav.navbar}>
        <img className={Nav.logo} src={assets.logo} alt=""/>
        <img className={Nav.profile} src={assets.profile_image} alt=""/>
    </div>
  )
}

export default Navbar